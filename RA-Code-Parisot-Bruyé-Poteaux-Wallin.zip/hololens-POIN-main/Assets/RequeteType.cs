public enum RequeteType
{
    IF,
    DECLARATION_VARIABLE,
    DECLARATION_FONCTION,
    FONCTION,
    VARIABLE,
    FOR,
    WHILE,
    NULL,
    FIN,
}
